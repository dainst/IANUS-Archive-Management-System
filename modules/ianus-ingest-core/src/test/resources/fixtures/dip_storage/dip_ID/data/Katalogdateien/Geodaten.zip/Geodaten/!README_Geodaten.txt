Anne Sieverling, 26.05.2016
Die Dateien im Ordner Geodaten wurden von IANUS erstellt um einen besseren Überblick über die Weiträumigkeit und umfangreiche Datenaufnahme des Projekts zu gewährleisten.
offensichtliche Fehler wurden dabei behoben, siehe folgende Liste:
ID		Änderung	Grund
D0217	E <-> N		E und N vertauscht
DK1891	E -> 9,59	Tippfehler
H0226/1	E -> 18,59	Tippfehler
UKR0056	E -> 36,30	Punkt statt Komma
B0576	E -> 5,29	Tippfehler
D4193	E -> 9,33	Tippfehler
I0215/2	E-> 17,38	Tippfehler
I0031	N -> 45,39	Tippfehler
I0032	N -> 45,39	Tippfehler
I0036/1	N -> 45,39	Tippfehler
I0036/2	N -> 45,39	Tippfehler
I0037	N -> 45,39	Tippfehler
I0038	N -> 45,39	Tippfehler
UKR0023	N -> 49,46	Tippfehler
UKR1120	N -> 50,07	Tippfehler
